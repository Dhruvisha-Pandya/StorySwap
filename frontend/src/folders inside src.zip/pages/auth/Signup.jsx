import { useState, useEffect } from "react";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";
import { useNavigate, Link } from "react-router-dom";
import "../../static/auth/Signup.css";
import { auth, db, GeoPoint, serverTimestamp } from "../../firebase/firebase";
import { useTheme } from "../../hooks/useTheme";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [username, setUsername] = useState("");
  const [location, setLocation] = useState(null);
  const [locationError, setLocationError] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const [theme, toggleTheme] = useTheme();

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) =>
          setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => setLocationError("Please enable location to find nearby books")
      );
    } else setLocationError("Geolocation not supported");
  }, []);

  const getPasswordStrengthText = (password) => {
    let strength = 0;
    if (password.length >= 6) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    if (strength <= 1) return "Weak";
    if (strength === 2) return "Moderate";
    return "Strong";
  };

  const isValidEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const blacklist = [
      "example.com",
      "test.com",
      "dummy.com",
      "mailinator.com",
      "fake.com",
    ];
    const domain = email.split("@")[1]?.toLowerCase();
    return regex.test(email) && !blacklist.includes(domain);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!isValidEmail(email)) return setError("Please enter a valid email");
    if (password !== confirmPassword) return setError("Passwords don't match");
    if (password.length < 6)
      return setError("Password must be at least 6 characters");
    if (!location) return setError("Location access is required");

    try {
      const usernameDoc = await getDoc(doc(db, "usernames", username));
      if (usernameDoc.exists()) throw new Error("Username already taken");

      const userCred = await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );
      await setDoc(doc(db, "users", userCred.user.uid), {
        username,
        email,
        location: new GeoPoint(location.lat, location.lng),
        createdAt: serverTimestamp(),
      });
      await setDoc(doc(db, "usernames", username), { uid: userCred.user.uid });
      navigate("/dashboard");
    } catch (err) {
      switch (err.code) {
        case "auth/email-already-in-use":
          setError("Email already registered");
          break;
        case "auth/weak-password":
          setError("Password must be at least 6 characters");
          break;
        default:
          setError(err.message || "Signup failed");
      }
    }
  };

  const passwordStrength = password ? getPasswordStrengthText(password) : "";

  return (
    <div className="signup-container">
      {/* 🌙 Light/Dark Theme Toggle */}
      <button
        className="theme-toggle-btn"
        aria-label="Toggle theme"
        onClick={toggleTheme}
      >
        {theme === "light" ? "🌙" : "☀️"}
      </button>

      <div className="signup-card">
        <Link to="/" className="back-link">
          ← Back to Home
        </Link>
        <h2>Create Your Account</h2>

        <div className={`location-status ${location ? "success" : "error"}`}>
          {location
            ? "📍 Location ready"
            : `⚠️ ${locationError || "Detecting location..."}`}
        </div>

        {error && <div className="error-message">{error}</div>}

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value.trim())}
            required
          />

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value.trim())}
            required
          />

          <div className="password-field">
            <input
              type="password"
              placeholder="Password (min 6 characters)"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            {/* Password strength BELOW the input */}
            {password && (
              <div
                className={`strength-text ${passwordStrength.toLowerCase()}`}
              >
                {passwordStrength}
              </div>
            )}
          </div>

          <input
            type="password"
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />

          <button type="submit" className="signup-button" disabled={!location}>
            Sign Up
          </button>
        </form>

        <p className="login-link">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
}
